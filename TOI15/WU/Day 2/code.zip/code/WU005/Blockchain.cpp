/*
FILE: cpp
*/
/*
LANG: C++
COMPILER: LINUX
*/
/*
TASK: blockchain.cpp
LANG: C++
AUTHOR: Theerawit Eamkhum
CENTER: WU
*/

#include <bits/stdc++.h>

using namespace std;
typedef pair<int,int> pii;
int check_tree(priority_queue <pii> x,int t,priority_queue<pii> y[]){
    int re=0,eq=0,siz=x.size();
    for(int i=0;i<t;i++){
        if(x.size()==y[i].size()){
            /*continue;
        }
        else{*/
            if(x.top()==y[i].top()){
                priority_queue<pii> p,q;
                p=y[i];
                q=x;
                //p.pop(); q.pop();
                while(!p.empty()){
                if(p.top()==q.top()){
                    eq++;
                    p.pop();
                    q.pop();
                }
                else
                    break;
            }

            if(eq==siz){
                re++;
            }
            eq=0;
            }
        }
    }

    return re;
}

int main(){
    int t,q; scanf("%d %d",&t,&q);
    priority_queue<pii> checktree[1000],tree[1000];
    int out[q];
    for(int i=0;i<(t+q);i++){
        int x; scanf("%d",&x);
        for(int j=0;j<x-1;j++){
            int n1,n2; scanf("%d %d",&n1,&n2);
            if(n1>n2){
                int tmp=n1;
                n1=n2;
                n2=tmp;
            }
            if(i<t){
                tree[i].push(make_pair(n1,n2));
            }
            else{
                checktree[i-t].push(make_pair(n1,n2));
            }
        }
        if(i>=t){
            out[i-t]=check_tree(checktree[i-t],t,tree);
        }
    }
    for(int i=0;i<q;i++){
        printf("%d\n",out[i]);
    }
}
