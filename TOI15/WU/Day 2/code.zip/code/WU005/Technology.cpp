/*
FILE: cpp
*/
/*
LANG: C++
COMPILER: LINUX
*/
/*
TASK: technology.cpp
LANG: C++
AUTHOR: Theerawit Eamkhum
CENTER: WU
*/
#include <bits/stdc++.h>

using namespace std;

int main(){
    int n,k,t; scanf("%d %d %d",&n,&k,&t);
    int tech[k+1],tech2[k+1],tech3[k+1];
    tech[0]=1;tech2[0]=0;tech3[0]=0;
    for(int i=1;i<k;i++){
        tech[i]=0;
        tech2[i]=0;
        tech3[i]=0;
    }
    int maxl=0,minl=k;
    for(int i=0;i<n;i++){
        int l,p; scanf("%d %d",&l,&p);
        if(l>maxl){maxl=l;}
        if(l<minl){minl=l;}
        tech2[l]++;
        if(p>0){
            int q[p];
            for(int j=0;j<p;j++){
                scanf("%d",&q[j]);
            }
            if(t>0){
            int ok=0;
            for(int j=0;j<p;j++){
                if(tech[q[j]]>0&&tech[l-1]>0){
                    ok++;
                }
            }
            if(ok==p){
                tech[i+1]=1;
                tech3[l]++;
                t--;
                }
            }
        }
        else{
            tech[i+1]=1;
            tech3[l]++;
            t--;
        }

    }
    int out=0;
    for(int i=maxl;i>=minl;i--){
        if(tech2[i]==tech3[i]){
            out=i;
            break;
        }
        /*else
            break;*/
    }
    if(out>0){
        printf("%d",out);
    }
    else
        printf("-1");

}
