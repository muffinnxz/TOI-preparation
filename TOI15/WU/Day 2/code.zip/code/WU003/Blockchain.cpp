/*
FILE: cpp
*/
/*
LANG: C++
COMPILER: LINUX
*/
#include <iostream>

using namespace std;

int main()
{

    cout<<"HELLO WORLD!"<<endl;

    return 0;
}
