/*
FILE: cpp
*/
/*
LANG: C++
COMPILER: LINUX
*/
/*
TASK: logistics.cpp
LANG: C++
AUTHOR: Todsapon Singsunjit
CENTER: Walailak
*/
#include <iostream>

using namespace std;

int main()
{
    int n,s,d,mf,tmp,m,x,y,outp=0;

    cin>>n;
    int f[n];
    for(short int i=0;i<n;i++)
        cin>>f[i];

    cin>>s>>d>>mf>>m;

    for(short int i=0;i<m;i++){
        cin>>x>>y>>tmp;
    }
    cout<<mf*f[s-1];

    return 0;
}
