/*
FILE: cpp
*/
/*
LANG: C++
COMPILER: LINUX
*/
/*
TASK: technology.cpp
LANG: C++
AUTHOR: Todsapon Singsunjit
CENTER: Walailak
*/
#include <iostream>

using namespace std;

int main()
{

    int n,k,t,tmp;
    cin>>n>>k>>t;
    int req[10000];

    int r,lev;
    //pair <int,pair<int,int> > inp[n];

    for(int i=0;i<n;i++){
        cin>>lev>>r;
        if(i==0)
            tmp = r;
        for(int j=0;j<r;j++){
            cin>>req[j];
        }

    //inp[i] = make_pair(r,make_pair(i,lev));
    }

    if(r==0)
    cout<<-1;
    else
    cout<<k;

    return 0;
}
