/*
FILE: cpp
*/
/*
LANG: C++
COMPILER: LINUX
*/
/*
TASK: technology.cpp
LANG: C++
AUTHOR: Nontawat Tongpron
CENTER: Walailak
*/

#include<iostream>

using namespace std;

int main()
{
    int n,k,t,cht=0,tmp=0;
    cin>>n>>k>>t;
    int div[n],numtech[n];
    int dev[n][100];

    for(int i=0; i<n; i++)
    {
        cin>>div[i]>>numtech[i];
        for(int j=0; j<numtech[i]; j++)
        {
            cin>>dev[i][j];
        }
    }

    while(cht!=t)
    {
        for(int i=0 ;i<n;i++)
        {
            if(numtech[i]==0)
            {
                cht++;
                tmp=div[i];
            }
            else
            {
                cht=t;
                break;
            }
        }
    }

    if(tmp==0)
    {
        cout<<"-1";
    }
    else
    {
        cout<<tmp;
    }
}
