/*
FILE: cpp
*/
/*
LANG: C++
COMPILER: LINUX
*/
/*
TASK: technology.cpp
LANG: C++
AUTHOR: YourName YourLastName
CENTER: YourCenter
*/

#include<bits/stdc++.h>

using namespace std;

typedef pair<int,int>PII;
int node,k,t,dist[100010],counter=0,start;
vector<PII>adj[100010];
vector<int>before[100010];
vector<int>level_node[100010];
bool visit[100010]={0};

void dijkstra(int x){
    priority_queue<PII>q;
    q.push(make_pair(0,x));
    dist[x]=0;
    level_node[counter].push_back(x);
    while(!q.empty()){
        int weight=q.top().first;
        x=q.top().second;
        q.pop();
        if(weight>t)
            continue;
        bool check=1;
        for(int i=0;i<before[x].size()&&check;i++){
            if(visit[before[x][i]]==0)
                check=0;
        }
        if(check=0)
            continue;
        visit[x]=1;
        for(int i=0;i<adj[x].size();i++){
            if(dist[adj[x][i].second]<weight+1){
            dist[adj[x][i].second]=weight+1;
            if(adj[x][i].second==start)
                counter++;
            level_node[counter].push_back(adj[x][i].second);
            q.push(make_pair(weight+1,adj[x][i].second));
            }
        }
    }
}

int main(){
    int time=0;
    scanf("%d%d%d",&node,&k,&t);
    for(int i=1;i<=node;i++){
        int level,counts;
        scanf("%d%d",&level,&counts);
        if(counts==0)
            start=i;
        for(int j=0;j<counts;j++){
            int x;
            scanf("%d",&x);
            before[i].push_back(x);
            adj[x].push_back(make_pair(level,i));
            adj[i].push_back(make_pair(level,x));
        }
    }
    for(int i=0;i<=node;i++)
        dist[i]=0;
    dijkstra(start);
    for(int i=0;i<=counter;i++){
        priority_queue<int,vector<int>,greater<int> >q;
        for(int j=0;j<level_node[i].size()-1;j++){
            q.push(adj[level_node[i][j]][level_node[i][j+1]].first);
        }
        int coun=1,temp=-1;
        while(!q.empty()){
            if(q.top()==coun){
                temp=coun;
                q.pop();
            }else if(q.top()==coun+1){
                coun++;
                temp=coun;
                q.pop();
            }else{
                break;
            }
        }
        if(time<temp)
            time=temp;
    }
    printf("2\n",time);
}
