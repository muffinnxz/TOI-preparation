/*
FILE: cpp
*/
/*
LANG: C++
COMPILER: LINUX
*/
/*
TASK: blockchain.cpp
LANG: C++
AUTHOR: Suppanut Ploywong
CENTER: WU
*/

#include <bits/stdc++.h>

using namespace std;

struct graph{
    int node,counts=0;
};

vector<int>adj_t[1010][1010];
int t,q,t_counts;
graph node_t[1010],node_q[1010];

int main(){
    scanf("%d%d",&t,&q);
    t_counts=0;
    for(int i=0;i<t;i++){
        int node_temp;
        scanf("%d",&node_temp);
        vector<int>temp[1010];
        for(int j=0;j<node_temp-1;j++){
            int x,y;
            scanf("%d%d",&x,&y);
            temp[x].push_back(y);
            temp[y].push_back(x);
        }
        if(i!=0){
            int check_all=0;
            for(int j=0;j<t_counts;j++){ //check same
                int check=1;
                //cout << endl << endl << node_t[i].node << ' ' << node_t[j].node << endl;
                if(node_temp==node_t[j].node){
                    for(int k=1;k<=node_t[j].node&&check;k++){  //node temp
                        for(int p=0;p<temp[k].size()&&check;p++){ //size temp
                            for(int q=0;q<adj_t[j][k].size();q++){ //size adj_t
                                if(adj_t[j][k][q]!=temp[k][p]){
                                    check=0;
                                }else{
                                    check=1;
                                    break;
                                }
                            }
                        }
                    }
                }else{
                    check=0;
                }

                if(check==1){
                    check_all=1;
                    node_t[j].counts++;
                    node_t[j].node=node_temp;
                    break;
                }
                //cout << check_all << endl;
            }
            if(check_all==0){
                node_t[t_counts].node=node_temp;
                for(int j=1;j<=node_t[t_counts].node;j++){
                    for(int k=0;k<temp[j].size();k++){
                        adj_t[t_counts][j].push_back(temp[j][k]);
                    }
                }
                node_t[t_counts].counts++;
                t_counts++;
            }
        }else{
            node_t[t_counts].node=node_temp;
            for(int j=1;j<=node_t[t_counts].node;j++){
                for(int k=0;k<temp[j].size();k++){
                    adj_t[t_counts][j].push_back(temp[j][k]);
                }
            }
            node_t[t_counts].counts++;
            t_counts++;
        }
    }
    int countans[q];
    for(int i=0;i<q;i++){
        scanf("%d",&node_q[i].node);
        vector<int>temp[1010];
        countans[i]=0;
        for(int j=0;j<node_q[i].node-1;j++){
            int x,y;
            scanf("%d%d",&x,&y);
            temp[x].push_back(y);
            temp[y].push_back(x);
        }
        for(int j=0;j<t_counts;j++){ //check same
            int check=1;
                if(node_t[j].node==node_q[i].node){
                    for(int k=1;k<=node_q[i].node&&check;k++){  //node temp
                        for(int p=0;p<temp[k].size()&&check;p++){ //size temp
                            for(int q=0;q<adj_t[j][k].size();q++){ //size adj_t
                                if(adj_t[j][k][q]!=temp[k][p]){
                                    check=0;
                                }else{
                                    check=1;
                                    break;
                                }
                            }
                        }
                    }
                }else{
                    check=0;
                }
            if(check)
                countans[i]+=node_t[j].counts;
        }
    }
    for(int i=0;i<q;i++)
        printf("%d\n",countans[i]);

    /*cout << endl << endl;
    for(int i=0;i<t_counts;i++){
        cout << node_t[i].node << ' ' << node_t[i].counts << endl;
    }
    cout << endl << endl << t_counts << endl;
    for(int i=0;i<t_counts;i++){
        if(node_t[i].counts!=0){
            for(int j=1;j<node_t[i].node;j++){
                for(int k=0;k<adj_t[i][j].size();k++){
                    cout << j << ' ' << adj_t[i][j][k] << endl;
                }
            }
        }
        cout << endl << endl;
    }*/
}
