/*
FILE: cpp
*/
/*
LANG: C++
COMPILER: LINUX
*/
#include <iostream>
using namespace std;
int main()
{
    int w,h,i,j,a=0,b,c,k;
    cin>>w>>h;
    char bit[h][w];
    for(i=0;i<h;i++)
    {
        for(j=0;j<w;j++)
        {
          cin>>bit[i][j];
        }
    }
   /* for(i=0;i<h;i++)
    {
        k=0;
        for(j=0+k;j<w;j++)
        {
          if(bit[i][j]=='1')
          {
            k=1;
            while(bit[i][j+k]=='1'&&bit[i][j+k]==bit[i+k][j])
            {
               k++;
            }
            cout<<k;
          }
        }

    }*/
    cout<<"0 0 0";
}
