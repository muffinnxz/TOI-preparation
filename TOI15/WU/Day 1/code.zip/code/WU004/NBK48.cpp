/*
FILE: cpp
*/
/*
LANG: C++
COMPILER: LINUX
*/
#include <iostream>
using namespace std;
int main()
{
    long long m,n,i,j,index=0;
    cin>>m>>n;
    long long cost[m];
    long long sumcost[m];
    sumcost[0]={0};
    long long afford[n];
    long long out[n];
    for(i=0;i<m;i++)
    {
        cin>>cost[i];
        if(i!=0)
        sumcost[i]=sumcost[i-1];
        sumcost[i]=sumcost[i]+cost[i];
    }
    for(i=0;i<n;i++)
    {
        cin>>afford[i];
    }
    for(j=0;j<n;j++)
    {
        index=0;
        for(i=m-1;i>=0;i--)
        {
            if(afford[j]>=sumcost[i])
            {
                out[j]=i+1;
                i=-1;
            }
            else if(afford[j]<sumcost[i])
                index++;
        }
        if(index==m)
        out[j]=0;
    }
    for(i=0;i<n;i++)
    {
        cout<<out[i]<<endl;
    }
}
