/*
FILE: cpp
*/
/*
LANG: C++
COMPILER: LINUX
*/
#include <iostream>
using namespace std;
int main()
{
    int w,h,i,j,a,b,c;
    cin>>w>>h;
    char bit[h][w];
    for(i=0;i<h;i++)
    {
        for(j=0;j<w;j++)
        {
          cin>>bit[i][j];
        }
    }
    for(i=0;i<h;i++)
    {
        for(j=0;j<w;j++)
        {
          if(bit[i][j]==1)
          {
            if(bit[i][j+1]&&bit[i+1][j])
            {
               a++;
            }
          }
        }
    }
    cout<<a;
}
