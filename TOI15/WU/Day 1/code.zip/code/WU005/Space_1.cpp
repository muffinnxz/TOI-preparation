/*
FILE: cpp
*/
/*
LANG: C++
COMPILER: LINUX
*/
/*
TASK: space.cpp
LANG: C++
AUTHOR: Theerawit Eamkhum
CENTER: WU
*/
#include <bits/stdc++.h>

using namespace std;

vector<int> check_shape(vector<int> v){
    vector<int> result;
    int sq=0,tri=0,rec=0;
    int x=0;
    for(int i=0;i<v.size();i++){
        if(v[i]==0){
            x++;
            continue;
        }
        else{
            if(v[i]==v[i+1]){
                sq++;
            }
            else if((v[i]!=v[i+1])){
                tri++;
            }
            else
                rec++;
        }
    }
    //for(int j=0;j<x;j++){
        if(sq>0){result.push_back(1);}
        if(tri>0) {result.push_back(2);}
        if(rec>0&&tri==0) {result.push_back(3);}
    //}
    return result;
}
int main(){
    int w,l; scanf("%d %d",&w,&l);
    int squere=0,tria=0,rect=0;
    string inpt[l];
    for(int i=0;i<l;i++){
        cin>>inpt[i];
    }
    vector<int> shape;
    for(int i=0;i<l;i++){
        int stat=0,one=0,pos=0,pos2=w;
        for(int j=pos;j<w;j++){
            if(inpt[i][j]=='1'){
                if(stat!=1){pos=j;}
                stat=1;
                one++;
            }
            else if(inpt[i][j]=='0'&&stat==1){
                break;
            }
        }
            shape.push_back(one);
            //cout<<one<<endl;
    }
    //for(int k=0;k<shape.size();k++){
                vector<int> c=check_shape(shape);
                for(int k=0;k<c.size();k++){
               // cout<<"c="<< c[k] <<endl;
                if(c[k]==1){
                    squere++;
                }
                else if(c[k]==2) {
                    tria++;
                }
                else if(c[k]==3) {
                    rect++;
                }
                }
            //cout<<one<<endl;
    //}
    cout<<squere<<' '<<rect<<' '<<tria;
}
