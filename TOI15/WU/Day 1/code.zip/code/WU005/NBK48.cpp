/*
FILE: cpp
*/
/*
LANG: C++
COMPILER: LINUX
*/
/*
TASK: nbk48.cpp
LANG: C++
AUTHOR: Theerawit Eamkhum
CENTER: WU
*/
#include <bits/stdc++.h>

using namespace std;

int main(){
    long long int n,customer,k;
    scanf("%lld %lld",&n,&customer);
    long long int inpt,co;
    vector<long long int> program,watch;
    scanf("%lld",&inpt);
    program.push_back(inpt);
    co=program[0];
    for(int i=1;i<n;i++){
        scanf("%lld",&inpt);
        co+=inpt;
        program.push_back(co);
    }
    for(int j=0;j<customer;j++){
        long long int cost1;
        scanf("%lld",&cost1);
        for(k=n-1;k>=0;k--){
            if(cost1>=program[k]){
                break;
            }
        }
        watch.push_back(k+1);
    }
    for(int i=0;i<customer;i++){
        printf("%lld\n",watch[i]);
    }

}
