/*
FILE: cpp
*/
/*
LANG: C++
COMPILER: LINUX
*/
/*
TASK: nbk48.cpp
LANG: C++
AUTHOR: Thanakorn Pho-jan
CENTER: WU
*/

#include <iostream>
#include <stdio.h>

using namespace std;

int main()
{
    int n,q,i,sum=0,j,qr=0,suml;
    scanf("%d %d",&n,&q);
    int book[n],money,opt[q];
    for(i=0;i<n;i++)
    {
        scanf("%d",&book[i]);
        sum+=book[i];
    }
    for(i=10000;i>=-10000;i--)
    {

    }
    for(i=0;i<q;i++)
    {
        scanf("%d",&money);
        qr=n;
        suml=sum;
        for(j=n-1;j>=0&&suml>money;j--)
        {
            suml-=book[j];
            qr--;
        }
        opt[i]=qr;
    }
    for(i=0;i<q;i++) printf("%d\n",opt[i]);
    return 0;
}
