/*
FILE: cpp
*/
/*
LANG: C++
COMPILER: LINUX
*/
/*
TASK: plantation.cpp
LANG: C++
AUTHOR: Thanakorn Pho-jan
CENTER: WU
*/

#include <bits/stdc++.h>

using namespace std;

int main()
{
    int w,i,j,k;
    bool check=0;
    scanf("%d",&w);
    bool opt[w];
    for(i=0;i<w;i++)
    {
        check=0;
        int t,r,s,sr,x,y;
        vector<int> sx,sy;
        scanf("%d %d %d",&t,&r,&s);
        sr=r*2+s;
        for(j=0;j<t;j++)
        {
            scanf("%d %d",&x,&y);
            for(k=0;k<sx.size()&&!check;k++)
            {
                if(abs(sx[i]-x)<sr&&abs(sy[i]-y)<sr)
                {
                    check=1;
                }
            }
            if(!check)
            {
                sx.push_back(x);
                sy.push_back(y);
                opt[i]=1;
            }else opt[i]=0;
        }
    }
    for(i=0;i<w;i++)
    {
        if(!opt[i]) printf("N\n");
        else printf("Y\n");
    }
    return 0;
}
