/*
FILE: cpp
*/
/*
LANG: C++
COMPILER: LINUX
*/
/*
TASK: nbk48.cpp
LANG: C++
AUTHOR: Suppanut Ploywong
CENTER: WU
*/

#include<bits/stdc++.h>

using namespace std;

struct tv_show{
    long long cost;
    int n;
};

void merges(tv_show *a,int low,int mid,int high){
    int i=low,j=mid+1,k=0;
    tv_show arr[high-low+1];
    while(i<=mid&&j<=high){
        if(a[i].cost<a[j].cost)
            arr[k++]=a[i++];
        else
            arr[k++]=a[j++];
    }
    while(i<=mid)
        arr[k++]=a[i++];
    while(j<=high)
        arr[k++]=a[j++];
    for(int p=0;p<k;p++)
        a[low++]=arr[p];
}

void merge_sort(tv_show *a,int low,int high){
    if(low<high){
        int mid=(low+high)/2;
        merge_sort(a,low,mid);
        merge_sort(a,mid+1,high);
        merges(a,low,mid,high);
    }
}

int main(){
    int n,q;
    scanf("%d%d",&n,&q);
    long long costs,counts=0;
    tv_show dp[n+1];
    for(int i=0;i<n;i++){
        scanf("%lld",&costs);
        counts+=costs;
        dp[i].cost=counts;
        dp[i].n=i+1;
    }
    merge_sort(dp,0,n-1);
    tv_show person[q];
    for(int i=0;i<q;i++){
        scanf("%lld",&person[i].cost);
        person[i].n=i;
    }
    merge_sort(person,0,q-1);
    /*for(int i=0;i<n;i++)
        printf("%ld %d\n",dp[i].cost,dp[i].n);*/
    int p_count=0,ans[q];
    long long n_max=0;
    for(;p_count<q;){
        if(person[p_count].cost<dp[0].cost){
            ans[person[p_count].n]=0;
            p_count++;
        }else
            break;
    }
    for(int i=0;i<n;i++){
        int start;
        if(person[p_count].cost<dp[i].cost){
            ans[person[p_count].n]=n_max;
            p_count++;
            i--;
        }
        if(n_max<dp[i].n){
            n_max=dp[i].n;
        }
    }
    for(int i=p_count;i<q;i++){
        ans[person[p_count].n]=n_max;
        p_count++;
    }

    for(int i=0;i<q;i++)
        printf("%d\n",ans[i]);
}
