/*
FILE: cpp
*/
/*
LANG: C++
COMPILER: LINUX
*/
/*
TASK: space.cpp
LANG: C++
AUTHOR: Suppanut Ploywong
CENTER: WU
*/

#include<bits/stdc++.h>

using namespace std;

char path[1010][1010];
bool visit[1010][1010]={0};
int n,m,counts;

void dfs(int x,int y){
    if(x>=0&&y>=0&&x<n&&y<m){
        if(visit[x][y]==0&&path[x][y]=='1'){
            visit[x][y]=1;
            counts++;
            dfs(x+1,y);
            dfs(x-1,y);
            dfs(x,y+1);
            dfs(x,y-1);
        }
    }
}

bool square(int x,int y,int counts){
    int check=1;
    int width=pow(counts,0.5);
    for(int i=0;i<width&&check;i++)
        for(int j=0;j<width&&check;j++)
            if(path[x+i][y+j]=='0')
                check=0;
    return check;
}

bool triangle1(int x,int y,int counts){
    int high;
    bool check=1;
    for(high=0;high<n;high++){
        if(path[x+high][y]=='0')
            break;
    }
    if(y-high<0)
        check=0;
    else if(y+high>m)
        check=0;
    int area=0;
    for(int i=0;i<high&&check;i++){
        for(int j=y-i;j<=y+i&&check;j++){
            area++;
        }
    }
    if(counts!=area)
        check=0;
    for(int i=0;i<high&&check;i++){
        for(int j=y-high;j<=y+high&&check;j++){
            if(path[x+i][j]=='1'&&j<y-i&&j>y+i)
                check=0;
            else if(path[x+i][j]=='0'&&j>=y-i&&j<=y+i)
                check=0;
        }
    }
    return check;
}

bool triangle2(int x,int y,int counts){
    bool check=1;
    int high;
    for(high=0;high<n;high++){
        if(path[x+high][y]=='0')
            break;
    }
    if(y-(high/2)<0)
        check=0;
    int area=0;
    for(int i=0;i<=high/2&&check;i++){
        for(int j=y-i;j<=y&&check;j++){
            area++;
        }
    }
    for(int i=high;i>high/2;i--){
        for(int j=y-(i-(high/2)-1);j<=y&&check;j++){
            area++;
        }
    }
    if(counts!=area)
        check=0;

    for(int i=0;i<=high/2&&check;i++){
        for(int j=y-high;j<=y&&check;j++){
            if(path[x+i][j]=='1'&&j<y-i)
                check=0;
            else if(path[x+i][j]=='0'&&j>=y-i)
                check=0;
            //cout << path[x+i][j] << ' ';
        }
        //cout << endl;
    }
    for(int i=high;i>high/2;i--){
        for(int j=y-high;j<=y&&check;j++){
            if(path[x+i][j]=='1'&&j<y-(i-(high/2)-1))
                check=0;
            else if(path[x+i][j]=='0'&&j>=y-(i-(high/2)-1))
                check=0;
            //cout << path[x+i][j] << ' ';
        }
        //cout << endl;
    }

    return check;
}

bool triangle3(int x,int y,int counts){

}

bool triangle4(int x,int y,int counts){

}

int main(){
    scanf("%d%d",&m,&n);
    int sq=0,di=0,tri=0;
    for(int i=0;i<n;i++){
        for(int j=0;j<m;j++){
            scanf(" %c",&path[i][j]);
        }
    }
    for(int i=0;i<n;i++){
        for(int j=0;j<m;j++){
            if(visit[i][j]==0&&path[i][j]=='1'){
                counts=0;
                dfs(i,j);
                int s=square(i,j,counts);
                int t=0;
                if(/*triangle1(i,j,counts)||*/triangle2(i,j,counts)){//||triangle3(i,j,counts)||triangle4(i,j,counts)){
                    t++;
                }
                sq+=s;
                tri+=t;
            }
        }
    }
    printf("%d %d %d",sq,di,tri);
}
