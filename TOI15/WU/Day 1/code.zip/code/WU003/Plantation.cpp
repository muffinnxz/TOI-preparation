/*
FILE: cpp
*/
/*
LANG: C++
COMPILER: LINUX
*/
/*
TASK: plantation.cpp
LANG: C++
AUTHOR: Todsapon Singsunjit
CENTER: Walailak
*/

#include <iostream>
#include <bits/stdc++.h>

using namespace std;

int main()
{

    int r,n,i,j,k,rad,t,des,x,y,tmp;
    cin>>n;
    bool out_p[n];

    for(i=0;i<n;i++)
        out_p[i]=0;

    for(r=0;r<n;r++){

        cin>>t>>rad>>des;
        pair <int,int> tree[t];

        for(i=0;i<t;i++){
            cin>>x>>y;
            tree[i] = make_pair(x,y);
        }

        for(i=0;i<t-1;i++){
            for(j=i+1;j<t;j++){

                x = (tree[i].first - tree[j].first);
                y = (tree[i].second - tree[j].second);
                tmp = sqrt(x*x + y*y);

                if(tmp < (rad*2)+des){
                    out_p[r]=1;
                    i=t;
                }
            }
        }
    }

    for(i=0;i<n;i++){
        if(out_p[i])
            cout<<"N\n";
        else
            cout<<"Y\n";

    }

    return 0;
}
