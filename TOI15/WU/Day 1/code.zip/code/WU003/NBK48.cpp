/*
FILE: cpp
*/
/*
LANG: C++
COMPILER: LINUX
*/
/*
TASK: nbk48.cpp
LANG: C++
AUTHOR: Todsapon Singsunjit
CENTER: Walailak
*/

#include <iostream>
#include <bits/stdc++.h>

using namespace std;

int main()
{

    int i,j,r,n,q,sum=0,tmp;

    cin>>n>>q;
    pair <int,int> p[n];
    int out_p[q];
    for(i=0;i<q;i++)
        out_p[i]=0;

    for(i=0;i<n;i++){
        cin>>tmp;
        sum+=tmp;
        p[i].first=i+1;
        p[i].second=sum;
    }

    sort(p,p+n);

    //ocout<<"DEBUG\n";for(int i=0;i<n;i++)cout<<p[i].first<<' '<<p[i].second<<'\n';cout<<"END_OF_DEBUG\n";
    for(r=0;r<q;r++){
        //cout<<"++++++++++++++++++++++++++++++++\n";
        cin>>tmp;

        for(j=n-1;j>=0;j--){

            if(p[j].second<=tmp){
                //cout<<"SET : "<<p[j].first<<'\n';
                out_p[r]=p[j].first;
                break;
            }
        }
    }

    for(i=0;i<q;i++)
        cout<<out_p[i]<<'\n';

    return 0;
}
