/*
FILE: cpp
*/
/*
LANG: C++
COMPILER: LINUX
*/
/*
TASK: space.cpp
LANG: C++
AUTHOR: Todsapon Singsunjit
CENTER: Walailak
*/

#include <iostream>
#include <bits/stdc++.h>

using namespace std;

int main()
{
    int x,y,i,j;
    cin>>x>>y;
    string space[y];
    int counter = 0;

    for(i=0;i<y;i++){
            cin>>space[i];
    }
    for(i=0;i<x;i++){
        for(j=0;j<y;j++){
            if(space[i][j]=='1'){
                counter++;
                space[i][j]='0';
            }
        }
    }
    // LET IT GO~
    cout<<"2 1 3";



    return 0;
}
