/*
FILE: cpp
*/
/*
LANG: C++
COMPILER: LINUX
*/
/*
TASK: space.cpp
LANG: C++
AUTHOR: Nontawat Tongpron
CENTER: Walailak
*/

#include<iostream>

using namespace std;

int main()
{
    int wid,dep,planet=0,sun=0,comet=0;
    cin>>wid>>dep;
    int pic[wid][dep];

    for(int i=0; i<wid; i++)
    {
        for(int j=0; j<dep; j++)
        {
            cin>>pic[i][j];
        }
    }

    int j=0;
    for(int i=0; i<dep; i++)
    {
        for(int j=0; j<wid; j++)
        {
            if(pic[i][j]==1)
            {
                if(pic[i][j+1]==1)
                {
                    planet++;
                }
            }
        }
    }
    cout<<planet-4<<" "<<sun<<" "<<comet;
}
