/*
FILE: cpp
*/
/*
LANG: C++
COMPILER: LINUX
*/
/*
TASK: nbk48.cpp
LANG: C++
AUTHOR: Nontawat Tongpron
CENTER: Walailak
*/

#include<iostream>


using namespace std;

int main()
{
    long int n,cus,total=0,temp;
    cin>>n>>cus;
    long int ep[n];
    for(long int i=0; i<n; i++)
    {
        cin>>ep[i];
        total+=ep[i];
    }

    temp=total;

    long int mon[cus];
    for(long int i=0; i<cus; i++)
    {
        cin>>mon[i];
    }

    for(long int i=0; i<cus; i++)
    {
        long int j=n,total=temp;
        while(mon[i]<total)
        {
            total-=ep[j-1];
            j--;

        }
        cout<<j<<endl;
    }
}

